using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

// DbContext class
public class PolicyDbContext : DbContext
{
    public DbSet<Policy> Policies { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        optionsBuilder.UseSqlServer("YourConnectionStringHere");
    }
}

// Command and Query Interfaces
public interface ICommand { }
public interface IQuery<TResult> { }

// Command Handlers
public class CreatePolicyCommand : ICommand
{
    public Policy Policy { get; set; }
}

public class UpdatePolicyCommand : ICommand
{
    public Policy Policy { get; set; }
}

public class DeletePolicyCommand : ICommand
{
    public string PolicyNumber { get; set; }
}

public class CreatePolicyHandler
{
    private readonly PolicyDbContext _context;

    public CreatePolicyHandler(PolicyDbContext context)
    {
        _context = context;
    }

    public async Task Handle(CreatePolicyCommand command)
    {
        _context.Policies.Add(command.Policy);
        await _context.SaveChangesAsync();
    }
}

public class UpdatePolicyHandler
{
    private readonly PolicyDbContext _context;

    public UpdatePolicyHandler(PolicyDbContext context)
    {
        _context = context;
    }

    public async Task Handle(UpdatePolicyCommand command)
    {
        _context.Policies.Update(command.Policy);
        await _context.SaveChangesAsync();
    }
}

public class DeletePolicyHandler
{
    private readonly PolicyDbContext _context;

    public DeletePolicyHandler(PolicyDbContext context)
    {
        _context = context;
    }

    public async Task Handle(DeletePolicyCommand command)
    {
        var policy = await _context.Policies.FindAsync(command.PolicyNumber);
        if (policy != null)
        {
            _context.Policies.Remove(policy);
            await _context.SaveChangesAsync();
        }
    }
}

// Query Handlers
public class GetPolicyByNumberQuery : IQuery<Policy>
{
    public string PolicyNumber { get; set; }
}

public class GetAllPoliciesQuery : IQuery<List<Policy>> { }

public class GetPolicyByNumberHandler
{
    private readonly PolicyDbContext _context;

    public GetPolicyByNumberHandler(PolicyDbContext context)
    {
        _context = context;
    }

    public async Task<Policy> Handle(GetPolicyByNumberQuery query)
    {
        return await _context.Policies.FindAsync(query.PolicyNumber);
    }
}

public class GetAllPoliciesHandler
{
    private readonly PolicyDbContext _context;

    public GetAllPoliciesHandler(PolicyDbContext context)
    {
        _context = context;
    }

    public async Task<List<Policy>> Handle(GetAllPoliciesQuery query)
    {
        return await _context.Policies.ToListAsync();
    }
}

// Controller
[ApiController]
[Route("api/[controller]")]
public class InsurancePolicyController : ControllerBase
{
    private readonly CreatePolicyHandler _createHandler;
    private readonly UpdatePolicyHandler _updateHandler;
    private readonly DeletePolicyHandler _deleteHandler;
    private readonly GetPolicyByNumberHandler _getByNumberHandler;
    private readonly GetAllPoliciesHandler _getAllHandler;

    public InsurancePolicyController(
        CreatePolicyHandler createHandler,
        UpdatePolicyHandler updateHandler,
        DeletePolicyHandler deleteHandler,
        GetPolicyByNumberHandler getByNumberHandler,
        GetAllPoliciesHandler getAllHandler)
    {
        _createHandler = createHandler;
        _updateHandler = updateHandler;
        _deleteHandler = deleteHandler;
        _getByNumberHandler = getByNumberHandler;
        _getAllHandler = getAllHandler;
    }

    [HttpPost]
    public async Task<IActionResult> CreatePolicy([FromBody] Policy policy)
    {
        await _createHandler.Handle(new CreatePolicyCommand { Policy = policy });
        return Ok();
    }

    [HttpPut]
    public async Task<IActionResult> UpdatePolicy([FromBody] Policy policy)
    {
        await _updateHandler.Handle(new UpdatePolicyCommand { Policy = policy });
        return Ok();
    }

    [HttpDelete("{policyNumber}")]
    public async Task<IActionResult> DeletePolicy(string policyNumber)
    {
        await _deleteHandler.Handle(new DeletePolicyCommand { PolicyNumber = policyNumber });
        return Ok();
    }

    [HttpGet("{policyNumber}")]
    public async Task<IActionResult> GetPolicyByNumber(string policyNumber)
    {
        var policy = await _getByNumberHandler.Handle(new GetPolicyByNumberQuery { PolicyNumber = policyNumber });
        if (policy == null)
        {
            return NotFound();
        }
        return Ok(policy);
    }

    [HttpGet]
    public async Task<IActionResult> GetAllPolicies()
    {
        var policies = await _getAllHandler.Handle(new GetAllPoliciesQuery());
        return Ok(policies);
    }
}

// Startup Configuration
public class Startup
{
    public void ConfigureServices(IServiceCollection services)
    {
        services.AddDbContext<PolicyDbContext>();
        services.AddScoped<CreatePolicyHandler>();
        services.AddScoped<UpdatePolicyHandler>();
        services.AddScoped<DeletePolicyHandler>();
        services.AddScoped<GetPolicyByNumberHandler>();
        services.AddScoped<GetAllPoliciesHandler>();
        services.AddControllers();
    }

    public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
    {
        if (env.IsDevelopment())
        {
            app.UseDeveloperExceptionPage();
        }

        app.UseRouting();

        app.UseEndpoints(endpoints =>
        {
            endpoints.MapControllers();
        });
    }
}