public interface INumber
{
    object Value { get; set; }
}

public class Number : INumber
{
    public object Value { get; set; }
}

